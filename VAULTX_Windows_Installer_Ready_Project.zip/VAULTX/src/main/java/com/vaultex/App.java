package com.vaultex;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.*;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import com.sun.net.httpserver.HttpServer;
import java.nio.file.*;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

public class App extends Application {
    private static final String GOLD = "#D8B46A";
    private static final String BG = "#0B0D12";
    private static final String PANEL = "#141821";
    private static final String MUTED = "#8E98A9";
    private Path root, stored, incoming, trash;
    private Connection db;
    private BorderPane shell;
    private VBox content;
    private Label status;
    private String section = "Dashboard";
    private WiFiServer wifi;

    @Override public void start(Stage stage) throws Exception {
        root = Path.of(System.getenv().getOrDefault("LOCALAPPDATA", System.getProperty("user.home")), "VAULTX");
        stored = root.resolve("files"); incoming = root.resolve("incoming"); trash = root.resolve("trash");
        Files.createDirectories(stored); Files.createDirectories(incoming); Files.createDirectories(trash);
        db = DriverManager.getConnection("jdbc:sqlite:" + root.resolve("vaultx.db"));
        initDb();
        shell = new BorderPane(); shell.setStyle("-fx-background-color:"+BG+";");
        shell.setLeft(sidebar());
        VBox top = new VBox(4); top.setPadding(new Insets(24,30,15,30));
        Label eyebrow = new Label("PERSONAL DIGITAL COMMAND CENTER"); eyebrow.setStyle("-fx-text-fill:"+GOLD+";-fx-font-size:10px;-fx-font-weight:bold;-fx-letter-spacing:2px;");
        Label title = new Label("VAULTX"); title.setFont(Font.font("Segoe UI", 27)); title.setStyle("-fx-text-fill:#F4F1EA;-fx-font-weight:bold;");
        top.getChildren().addAll(eyebrow,title);
        shell.setTop(top);
        content = new VBox(18); content.setPadding(new Insets(10,30,30,30));
        ScrollPane scroll = new ScrollPane(content); scroll.setFitToWidth(true); scroll.setStyle("-fx-background:transparent;-fx-background-color:transparent;");
        shell.setCenter(scroll);
        status = new Label("LOCAL STORAGE • PRIVATE"); status.setStyle("-fx-text-fill:"+MUTED+";-fx-font-size:11px;");
        HBox foot = new HBox(status); foot.setPadding(new Insets(12,30,15,30)); shell.setBottom(foot);
        showDashboard();
        Scene scene = new Scene(shell, 1220, 780); scene.setFill(Color.web(BG));
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        scene.setOnKeyPressed(e -> {
            if (e.isControlDown() && e.getCode() == KeyCode.O) importFiles();
            else if (e.isControlDown() && e.getCode() == KeyCode.L) addLink();
            else if (e.getCode() == KeyCode.F5) navigate(section);
        });
        shell.setOnDragOver(e -> {
            if (e.getGestureSource() != shell && e.getDragboard().hasFiles()) e.acceptTransferModes(TransferMode.COPY);
            e.consume();
        });
        shell.setOnDragDropped(e -> {
            List<File> dropped = e.getDragboard().getFiles();
            boolean ok = !dropped.isEmpty();
            if (ok) importFileList(dropped);
            e.setDropCompleted(ok); e.consume();
        });
        stage.setTitle("VAULTX — Digital Storage"); stage.setMinWidth(900); stage.setMinHeight(620); stage.setScene(scene); stage.show();
    }

    private void initDb() throws SQLException {
        try (Statement s=db.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY, name TEXT NOT NULL, stored_name TEXT NOT NULL, original_path TEXT, folder TEXT DEFAULT 'General', size INTEGER, type TEXT, added TEXT, favorite INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS links(id INTEGER PRIMARY KEY, title TEXT, url TEXT NOT NULL, description TEXT, folder TEXT DEFAULT 'General', added TEXT, favorite INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY, name TEXT, direction TEXT, size INTEGER, result TEXT, time TEXT)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS folders(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, created TEXT)");
            s.executeUpdate("INSERT OR IGNORE INTO folders(name,created) VALUES('General','" + now() + "')");
            try { s.executeUpdate("ALTER TABLE files ADD COLUMN sha256 TEXT"); } catch (SQLException ignored) { }
            try { s.executeUpdate("ALTER TABLE files ADD COLUMN notes TEXT DEFAULT ''"); } catch (SQLException ignored) { }
        }
    }

    private VBox sidebar() {
        VBox box = new VBox(8); box.setPadding(new Insets(25,15,20,15)); box.setPrefWidth(220);
        box.setStyle("-fx-background-color:#10141C;-fx-border-color:#222936;-fx-border-width:0 1 0 0;");
        Label brand = new Label("V  VAULTX"); brand.setStyle("-fx-text-fill:"+GOLD+";-fx-font-size:18px;-fx-font-weight:bold;"); brand.setPadding(new Insets(0,0,24,8));
        box.getChildren().add(brand);
        for (String name : List.of("Dashboard","All Files","Folders","Links","Favorites","Recent","Phone Transfer","Transfer History","Trash","Settings")) {
            Button b = new Button(name); b.setMaxWidth(Double.MAX_VALUE); b.setAlignment(Pos.CENTER_LEFT);
            b.setStyle(navStyle(name.equals(section)));
            b.setOnAction(e -> navigate(name)); box.getChildren().add(b);
        }
        Region spacer = new Region(); VBox.setVgrow(spacer,Priority.ALWAYS);
        Label local = new Label("●  LOCAL VAULT  /  v1.0"); local.setStyle("-fx-text-fill:#6F7A8B;-fx-font-size:9px;"); box.getChildren().addAll(spacer,local);
        return box;
    }
    private String navStyle(boolean active) { return "-fx-background-color:"+(active?"#29251D":"transparent")+";-fx-text-fill:"+(active?GOLD:"#B8C0CC")+";-fx-font-size:13px;-fx-padding:12 14;-fx-background-radius:9;-fx-cursor:hand;"; }
    private void navigate(String name) {
        section=name; shell.setLeft(sidebar()); content.getChildren().clear();
        switch(name) {
            case "Dashboard" -> showDashboard();
            case "All Files" -> showFiles(false,false);
            case "Folders" -> showFolders();
            case "Links" -> showLinks();
            case "Favorites" -> showFavorites();
            case "Recent" -> showFiles(false,true);
            case "Phone Transfer" -> showTransfer();
            case "Transfer History" -> showHistory();
            case "Trash" -> showTrash();
            case "Settings" -> showSettings();
        }
    }
    private Label heading(String s,String sub) {
        Label h=new Label(s); h.setStyle("-fx-text-fill:#F3F0E9;-fx-font-size:23px;-fx-font-weight:bold;");
        Label d=new Label(sub); d.setStyle("-fx-text-fill:"+MUTED+";-fx-font-size:12px;");
        content.getChildren().addAll(h,d); return h;
    }
    private HBox row(Node... nodes) { HBox h=new HBox(12,nodes); h.setAlignment(Pos.CENTER_LEFT); return h; }
    private VBox panel(String title, String value) {
        VBox p=new VBox(8); p.setPadding(new Insets(18)); p.setStyle("-fx-background-color:"+PANEL+";-fx-background-radius:14;-fx-border-color:#252D3A;-fx-border-radius:14;");
        Label t=new Label(title.toUpperCase()); t.setStyle("-fx-text-fill:"+MUTED+";-fx-font-size:10px;-fx-font-weight:bold;");
        Label v=new Label(value); v.setStyle("-fx-text-fill:#F4F1EA;-fx-font-size:22px;-fx-font-weight:bold;");
        p.getChildren().addAll(t,v); HBox.setHgrow(p,Priority.ALWAYS); return p;
    }
    private void showDashboard() {
        content.getChildren().clear(); heading("Your vault, beautifully organized","A private home for everything digital.");
        try {
            int fc=count("files","deleted=0"), lc=count("links","deleted=0");
            long bytes=scalar("SELECT COALESCE(SUM(size),0) FROM files WHERE deleted=0");
            content.getChildren().add(row(panel("Stored files",String.valueOf(fc)),panel("Saved links",String.valueOf(lc)),panel("Storage used",human(bytes))));
        } catch(Exception e){ error(e); }
        HBox actions=row(action("＋  Import files",this::importFiles),action("↗  Save a link",this::addLink),action("⇄  Phone transfer",()->navigate("Phone Transfer")));
        content.getChildren().add(actions);
        Label recent=new Label("Recently added"); recent.setStyle("-fx-text-fill:#F4F1EA;-fx-font-size:16px;-fx-font-weight:bold;");
        content.getChildren().add(recent); showFileTable(false,true,false);
        content.getChildren().add(new Label("Tip: use Ctrl+O to import files, Ctrl+L to save a link, and F5 to refresh the current view."));

    }
    private Button action(String text,Runnable run) { Button b=new Button(text); b.setOnAction(e->run.run()); b.setStyle("-fx-background-color:#242A35;-fx-text-fill:"+GOLD+";-fx-padding:13 18;-fx-background-radius:10;-fx-cursor:hand;"); return b; }
    private void showFavorites() {
        content.getChildren().clear();heading("Favorites","Your pinned files and saved links.");
        Label filesLabel=new Label("FAVORITE FILES");filesLabel.setStyle("-fx-text-fill:"+GOLD+";-fx-font-weight:bold;");
        content.getChildren().add(filesLabel);showFileTable(true,false,false);
        Label linksLabel=new Label("FAVORITE LINKS");linksLabel.setStyle("-fx-text-fill:"+GOLD+";-fx-font-weight:bold;");
        content.getChildren().add(linksLabel);
        TableView<LinkRec> table=new TableView<>();table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<LinkRec,String> title=new TableColumn<>("TITLE");title.setCellValueFactory(v->v.getValue().title);
        TableColumn<LinkRec,String> url=new TableColumn<>("URL");url.setCellValueFactory(v->v.getValue().url);
        table.getColumns().addAll(title,url);table.setPrefHeight(220);
        try(Statement st=db.createStatement();ResultSet rs=st.executeQuery("SELECT * FROM links WHERE deleted=0 AND favorite=1 ORDER BY id DESC")){
            var rows=FXCollections.<LinkRec>observableArrayList();while(rs.next())rows.add(new LinkRec(rs.getInt("id"),rs.getString("title"),rs.getString("url"),rs.getString("description")));table.setItems(rows);
        }catch(Exception e){error(e);}
        table.setRowFactory(tv->{TableRow<LinkRec> r=new TableRow<>();ContextMenu m=new ContextMenu();MenuItem open=new MenuItem("Open"),unpin=new MenuItem("Remove from favorites");
            open.setOnAction(e->browse(r.getItem().url.get()));unpin.setOnAction(e->{update("UPDATE links SET favorite=0 WHERE id=?",r.getItem().id);navigate("Favorites");});
            m.getItems().addAll(open,unpin);r.contextMenuProperty().bind(javafx.beans.binding.Bindings.when(r.emptyProperty()).then((ContextMenu)null).otherwise(m));return r;});
        content.getChildren().add(table);
    }
    private void showFiles(boolean fav,boolean recent) {
        content.getChildren().clear(); heading(fav?"Favorites":recent?"Recently added":"All files","Search, organize, open and export your stored files.");
        HBox tools=row(action("＋ Import files",this::importFiles),action("＋ New folder",this::newFolder));
        TextField search=new TextField(); search.setPromptText("Search files by name or type…"); search.setPrefWidth(300);
        Button go=action("Search",()->refreshFileTable(search.getText(),fav,recent));
        tools.getChildren().addAll(search,go); content.getChildren().add(tools);
        showFileTable(fav,recent,false);
    }
    private void showFileTable(boolean fav,boolean recent,boolean trashOnly) {
        TableView<FileRec> table=new TableView<>(); table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<FileRec,String> name=new TableColumn<>("FILE"); name.setCellValueFactory(v->v.getValue().name);
        TableColumn<FileRec,String> type=new TableColumn<>("TYPE"); type.setCellValueFactory(v->v.getValue().type);
        TableColumn<FileRec,String> size=new TableColumn<>("SIZE"); size.setCellValueFactory(v->v.getValue().size);
        TableColumn<FileRec,String> folder=new TableColumn<>("FOLDER"); folder.setCellValueFactory(v->v.getValue().folder);
        TableColumn<FileRec,String> date=new TableColumn<>("ADDED"); date.setCellValueFactory(v->v.getValue().added);
        table.getColumns().addAll(name,type,size,folder,date); table.setPrefHeight(390);
        refreshTableInto(table,"",fav,recent,trashOnly); content.getChildren().add(table);
        table.setRowFactory(tv->{TableRow<FileRec> r=new TableRow<>(); ContextMenu menu=new ContextMenu();
            MenuItem open=new MenuItem("Open"), export=new MenuItem("Export copy"), favorite=new MenuItem("Toggle favorite"), rename=new MenuItem("Rename"), move=new MenuItem("Move to folder"), details=new MenuItem("File details"), delete=new MenuItem(trashOnly?"Restore":"Move to Trash"), permanent=new MenuItem("Delete permanently");
            open.setOnAction(e->openFile(r.getItem())); export.setOnAction(e->exportFile(r.getItem())); favorite.setOnAction(e->toggleFavorite(r.getItem()));
            rename.setOnAction(e->renameFile(r.getItem())); move.setOnAction(e->moveFileToFolder(r.getItem())); details.setOnAction(e->fileDetails(r.getItem()));
            delete.setOnAction(e->{if(trashOnly)restoreFile(r.getItem());else trashFile(r.getItem());});
            permanent.setOnAction(e->permanentlyDelete(r.getItem()));
            menu.getItems().addAll(open,export,favorite,rename,move,details,delete);
            if (trashOnly) menu.getItems().add(permanent); r.contextMenuProperty().bind(javafx.beans.binding.Bindings.when(r.emptyProperty()).then((ContextMenu)null).otherwise(menu)); return r;});
    }
    private void refreshFileTable(String q,boolean f,boolean r) { for(var n:content.getChildren()) if(n instanceof TableView<?> t){ refreshTableInto((TableView<FileRec>)t,q,f,r,false); break; } }
    private void refreshTableInto(TableView<FileRec> table,String q,boolean fav,boolean recent,boolean trashOnly) {
        try { String sql="SELECT * FROM files WHERE deleted=?"+(fav?" AND favorite=1":"")+(q.isBlank()?"":" AND (name LIKE ? OR type LIKE ?)")+(recent?" ORDER BY id DESC":" ORDER BY name COLLATE NOCASE");
            PreparedStatement p=db.prepareStatement(sql); p.setInt(1,trashOnly?1:0); if(!q.isBlank()){p.setString(2,"%"+q+"%");p.setString(3,"%"+q+"%");}
            ResultSet rs=p.executeQuery(); var list=FXCollections.<FileRec>observableArrayList();
            while(rs.next()) list.add(new FileRec(rs.getInt("id"),rs.getString("name"),rs.getString("stored_name"),rs.getString("type"),human(rs.getLong("size")),rs.getString("folder"),rs.getString("added")));
            table.setItems(list); rs.close();p.close();
        }catch(Exception e){error(e);}
    }
    private void importFiles() {
        FileChooser fc=new FileChooser(); fc.setTitle("Import files into VAULTX");
        List<File> chosen=fc.showOpenMultipleDialog(shell.getScene().getWindow());
        if(chosen!=null) importFileList(chosen);
    }
    private void importFileList(List<File> chosen) {
        if (chosen == null || chosen.isEmpty()) return;
        List<String> folders = getFolderNames();
        ChoiceDialog<String> folderDialog = new ChoiceDialog<>(folders.contains("General") ? "General" : folders.get(0), folders);
        folderDialog.setTitle("Import destination"); folderDialog.setHeaderText("Choose a VAULTX folder");
        String destination = folderDialog.showAndWait().orElse("General");
        Task<String> task=new Task<>() {
            protected String call() throws Exception {
                int added=0, duplicates=0;
                for(File f:chosen) {
                    Path src=f.toPath();
                    if (!Files.isRegularFile(src)) continue;
                    String hash=sha256(src);
                    try(PreparedStatement check=db.prepareStatement("SELECT id FROM files WHERE sha256=? AND deleted=0")) {
                        check.setString(1,hash);
                        try(ResultSet rs=check.executeQuery()){if(rs.next()){duplicates++;continue;}}
                    }
                    String key=UUID.randomUUID()+"_"+safe(src.getFileName().toString());
                    Path dst=stored.resolve(key); Files.copy(src,dst,StandardCopyOption.COPY_ATTRIBUTES);
                    try(PreparedStatement p=db.prepareStatement("INSERT INTO files(name,stored_name,original_path,folder,size,type,added,sha256) VALUES(?,?,?,?,?,?,?,?)")) {
                        p.setString(1,src.getFileName().toString());p.setString(2,key);p.setString(3,src.toString());
                        p.setString(4,destination);p.setLong(5,Files.size(dst));p.setString(6,extension(src));
                        p.setString(7,now());p.setString(8,hash);p.executeUpdate();
                    }
                    added++;
                }
                return added+" added • "+duplicates+" duplicate(s) skipped";
            }
        };
        task.setOnSucceeded(e->{status.setText(task.getValue());navigate(section);});
        task.setOnFailed(e->error(task.getException()));
        Thread worker=new Thread(task,"vaultx-import");worker.setDaemon(true);worker.start();
    }
    private static String sha256(Path file) throws Exception {
        java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");
        try(InputStream in=Files.newInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))>0)md.update(b,0,n);}
        return java.util.HexFormat.of().formatHex(md.digest());
    }
    private void addLink() {
        Dialog<ButtonType> d=new Dialog<>(); d.setTitle("Save a link"); TextField title=new TextField();title.setPromptText("Link name");
        TextField url=new TextField();url.setPromptText("https://example.com"); TextArea desc=new TextArea();desc.setPromptText("Description / notes");desc.setPrefRowCount(3);
        VBox box=new VBox(10,title,url,desc);box.setPadding(new Insets(10));d.getDialogPane().setContent(box);d.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
        d.showAndWait().ifPresent(b->{if(b==ButtonType.OK)try{String u=url.getText().trim();if(!u.matches("(?i)^https?://.+"))throw new IllegalArgumentException("Enter a valid http or https URL.");
            try(PreparedStatement p=db.prepareStatement("INSERT INTO links(title,url,description,folder,added) VALUES(?,?,?,?,?)")){p.setString(1,title.getText().isBlank()?u:title.getText());p.setString(2,u);p.setString(3,desc.getText());p.setString(4,"General");p.setString(5,now());p.executeUpdate();} navigate("Links");
        }catch(Exception ex){error(ex);}});
    }
    private void showLinks() {
        content.getChildren().clear();heading("Link library","Keep useful websites, references and resources close at hand.");
        HBox linkTools=row(action("＋ Save new link",this::addLink));
        TextField linkSearch=new TextField();linkSearch.setPromptText("Search title, URL or description…");linkSearch.setPrefWidth(340);
        linkTools.getChildren().addAll(linkSearch,action("Search",()->refreshLinks(linkSearch.getText())));
        content.getChildren().add(linkTools);
        TableView<LinkRec> t=new TableView<>();t.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<LinkRec,String> a=new TableColumn<>("TITLE");a.setCellValueFactory(v->v.getValue().title);
        TableColumn<LinkRec,String> b=new TableColumn<>("URL");b.setCellValueFactory(v->v.getValue().url);
        TableColumn<LinkRec,String> c=new TableColumn<>("DESCRIPTION");c.setCellValueFactory(v->v.getValue().desc);
        t.getColumns().addAll(a,b,c);t.setPrefHeight(480);
        try(Statement s=db.createStatement();ResultSet rs=s.executeQuery("SELECT * FROM links WHERE deleted=0 ORDER BY id DESC")){var l=FXCollections.<LinkRec>observableArrayList();while(rs.next())l.add(new LinkRec(rs.getInt("id"),rs.getString("title"),rs.getString("url"),rs.getString("description")));t.setItems(l);}catch(Exception e){error(e);}
        t.setRowFactory(tv->{TableRow<LinkRec> r=new TableRow<>();ContextMenu m=new ContextMenu();MenuItem open=new MenuItem("Open link"),copy=new MenuItem("Copy URL"),favorite=new MenuItem("Toggle favorite"),edit=new MenuItem("Edit"),del=new MenuItem("Move to Trash");
            open.setOnAction(e->browse(r.getItem().url.get()));copy.setOnAction(e->{var cb=javafx.scene.input.Clipboard.getSystemClipboard();var cc=new ClipboardContent();cc.putString(r.getItem().url.get());cb.setContent(cc);});
            favorite.setOnAction(e->{update("UPDATE links SET favorite=1-favorite WHERE id=?",r.getItem().id);navigate("Links");});
            edit.setOnAction(e->editLink(r.getItem()));
            del.setOnAction(e->{update("UPDATE links SET deleted=1 WHERE id=?",r.getItem().id);navigate("Links");});
            m.getItems().addAll(open,copy,favorite,edit,del);r.contextMenuProperty().bind(javafx.beans.binding.Bindings.when(r.emptyProperty()).then((ContextMenu)null).otherwise(m));return r;});
        content.getChildren().add(t);
    }
    private void refreshLinks(String query) {
        for(Node n:content.getChildren()) if(n instanceof TableView<?> raw) {
            @SuppressWarnings("unchecked") TableView<LinkRec> table=(TableView<LinkRec>)raw;
            try(PreparedStatement p=db.prepareStatement("SELECT * FROM links WHERE deleted=0 AND (title LIKE ? OR url LIKE ? OR description LIKE ?) ORDER BY id DESC")) {
                String q="%"+query+"%";p.setString(1,q);p.setString(2,q);p.setString(3,q);
                try(ResultSet r=p.executeQuery()){var rows=FXCollections.<LinkRec>observableArrayList();while(r.next())rows.add(new LinkRec(r.getInt("id"),r.getString("title"),r.getString("url"),r.getString("description")));table.setItems(rows);}
            }catch(Exception e){error(e);}break;
        }
    }
    private void editLink(LinkRec link) {
        if(link==null)return;
        TextInputDialog title=new TextInputDialog(link.title.get());title.setTitle("Edit link");title.setHeaderText("Link title");
        title.showAndWait().ifPresent(t->{TextInputDialog url=new TextInputDialog(link.url.get());url.setTitle("Edit URL");url.setHeaderText("Link address");
            url.showAndWait().ifPresent(u->{try{if(!u.matches("(?i)^https?://.+"))throw new IllegalArgumentException("URL must begin with http:// or https://");
                try(PreparedStatement p=db.prepareStatement("UPDATE links SET title=?,url=? WHERE id=?")){p.setString(1,t);p.setString(2,u);p.setInt(3,link.id);p.executeUpdate();}navigate("Links");
            }catch(Exception ex){error(ex);}});
        });
    }
    private void showFolders() {
        content.getChildren().clear();heading("Folders","Your own collections. Select a folder to view its files.");
        content.getChildren().add(action("＋ Create folder",this::newFolder));
        try(Statement s=db.createStatement();ResultSet rs=s.executeQuery(
                "SELECT f.name, COUNT(x.id) AS n FROM folders f LEFT JOIN files x ON x.folder=f.name AND x.deleted=0 GROUP BY f.name ORDER BY f.name")) {
            while(rs.next()){
                String folder=rs.getString("name"); int n=rs.getInt("n");
                content.getChildren().add(action("▰  "+folder+"     •     "+n+" file(s)",()->showFolderContents(folder)));
            }
        }catch(Exception e){error(e);}
    }
    private void showFolderContents(String folder) {
        content.getChildren().clear();heading(folder,"Files saved in this collection.");
        content.getChildren().add(action("＋ Import into this folder",()->importIntoFolder(folder)));
        TableView<FileRec> table=new TableView<>();table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<FileRec,String> n=new TableColumn<>("FILE");n.setCellValueFactory(v->v.getValue().name);
        TableColumn<FileRec,String> t=new TableColumn<>("TYPE");t.setCellValueFactory(v->v.getValue().type);
        TableColumn<FileRec,String> z=new TableColumn<>("SIZE");z.setCellValueFactory(v->v.getValue().size);
        table.getColumns().addAll(n,t,z);table.setPrefHeight(430);
        try(PreparedStatement p=db.prepareStatement("SELECT * FROM files WHERE deleted=0 AND folder=? ORDER BY name")) {
            p.setString(1,folder);try(ResultSet rs=p.executeQuery()){var rows=FXCollections.<FileRec>observableArrayList();
                while(rs.next())rows.add(new FileRec(rs.getInt("id"),rs.getString("name"),rs.getString("stored_name"),rs.getString("type"),human(rs.getLong("size")),rs.getString("folder"),rs.getString("added")));
                table.setItems(rows);}
        }catch(Exception e){error(e);}
        table.setRowFactory(tv->{TableRow<FileRec> r=new TableRow<>();ContextMenu m=new ContextMenu();
            MenuItem open=new MenuItem("Open"),move=new MenuItem("Move to folder"),fav=new MenuItem("Toggle favorite"),del=new MenuItem("Move to Trash");
            open.setOnAction(e->openFile(r.getItem()));move.setOnAction(e->moveFileToFolder(r.getItem()));fav.setOnAction(e->toggleFavorite(r.getItem()));del.setOnAction(e->trashFile(r.getItem()));
            m.getItems().addAll(open,move,fav,del);r.contextMenuProperty().bind(javafx.beans.binding.Bindings.when(r.emptyProperty()).then((ContextMenu)null).otherwise(m));return r;});
        content.getChildren().add(table);content.getChildren().add(action("← Back to folders",()->navigate("Folders")));
    }
    private void importIntoFolder(String folder) {
        FileChooser fc=new FileChooser();fc.setTitle("Import into "+folder);
        List<File> chosen=fc.showOpenMultipleDialog(shell.getScene().getWindow());
        if(chosen==null||chosen.isEmpty())return;
        importFilesInto(chosen,folder);
    }
    private void importFilesInto(List<File> chosen,String folder) {
        Task<Void> task=new Task<>(){protected Void call()throws Exception{
            for(File f:chosen){Path p=f.toPath();String hash=sha256(p);
                try(PreparedStatement q=db.prepareStatement("SELECT id FROM files WHERE sha256=? AND deleted=0")){q.setString(1,hash);try(ResultSet r=q.executeQuery()){if(r.next())continue;}}
                String key=UUID.randomUUID()+"_"+safe(p.getFileName().toString());Path dst=stored.resolve(key);Files.copy(p,dst);
                try(PreparedStatement q=db.prepareStatement("INSERT INTO files(name,stored_name,original_path,folder,size,type,added,sha256) VALUES(?,?,?,?,?,?,?,?)")){
                    q.setString(1,p.getFileName().toString());q.setString(2,key);q.setString(3,p.toString());q.setString(4,folder);q.setLong(5,Files.size(dst));q.setString(6,extension(p));q.setString(7,now());q.setString(8,hash);q.executeUpdate();}
            }return null;}};
        task.setOnSucceeded(e->{status.setText("FOLDER IMPORT COMPLETE");showFolderContents(folder);});
        task.setOnFailed(e->error(task.getException()));Thread t=new Thread(task,"vaultx-folder-import");t.setDaemon(true);t.start();
    }
    private void newFolder() {
        TextInputDialog d=new TextInputDialog();d.setTitle("New folder");d.setHeaderText("Create a folder");d.setContentText("Folder name:");
        d.showAndWait().ifPresent(v->{if(!v.isBlank())try{
            String name=v.trim();try(PreparedStatement p=db.prepareStatement("INSERT INTO folders(name,created) VALUES(?,?)")){p.setString(1,name);p.setString(2,now());p.executeUpdate();}
            Files.createDirectories(stored.resolve(safe(name)));navigate("Folders");
        }catch(Exception e){error(e);}});
    }
    private List<String> getFolderNames() {
        List<String> names=new ArrayList<>();
        try(Statement s=db.createStatement();ResultSet r=s.executeQuery("SELECT name FROM folders ORDER BY name")){while(r.next())names.add(r.getString(1));}
        catch(Exception e){error(e);}
        if(names.isEmpty())names.add("General");return names;
    }
    private void moveFileToFolder(FileRec f) {
        if(f==null)return;List<String> names=getFolderNames();
        ChoiceDialog<String> d=new ChoiceDialog<>(f.folder.get(),names);d.setTitle("Move file");d.setHeaderText("Choose destination folder");
        d.showAndWait().ifPresent(folder->{updateText("UPDATE files SET folder=? WHERE id=?",folder,f.id);navigate(section);});
    }
    private void fileDetails(FileRec f) {
        if(f==null)return;
        try(PreparedStatement p=db.prepareStatement("SELECT original_path,sha256,notes FROM files WHERE id=?")) {
            p.setInt(1,f.id);try(ResultSet r=p.executeQuery()){if(r.next()){
                Alert a=new Alert(Alert.AlertType.INFORMATION);a.setTitle("File details");a.setHeaderText(f.name.get());
                a.setContentText("Type: "+f.type.get()+"\\nSize: "+f.size.get()+"\\nFolder: "+f.folder.get()+"\\nAdded: "+f.added.get()+"\\nOriginal path: "+r.getString(1)+"\\nSHA-256: "+r.getString(2));a.showAndWait();
            }}
        }catch(Exception e){error(e);}
    }
    private void permanentlyDelete(FileRec f) {
        if(f==null)return;Alert confirm=new Alert(Alert.AlertType.CONFIRMATION,"Permanently delete this file from VAULTX?",ButtonType.YES,ButtonType.NO);
        confirm.showAndWait().ifPresent(b->{if(b==ButtonType.YES)try{
            try(PreparedStatement q=db.prepareStatement("SELECT stored_name FROM files WHERE id=?")){q.setInt(1,f.id);try(ResultSet r=q.executeQuery()){if(r.next())Files.deleteIfExists(stored.resolve(r.getString(1)));}}
            try(PreparedStatement q=db.prepareStatement("DELETE FROM files WHERE id=?")){q.setInt(1,f.id);q.executeUpdate();}
            navigate("Trash");
        }catch(Exception e){error(e);}});
    }
    private void showTransfer() {
        content.getChildren().clear();heading("Phone transfer","Move files between your phone and PC over a trusted local connection.");
        content.getChildren().addAll(panel("Bluetooth","Windows built-in transfer"),action("Open Bluetooth Transfer",()->{
            try{new ProcessBuilder("cmd","/c","start","","fsquirt.exe").start();status.setText("BLUETOOTH WIZARD OPENED");}catch(Exception e){error(e);}
        }));
        content.getChildren().add(new Label("Wi-Fi transfer"));content.getChildren().add(new Label("Connect both devices to the same Wi-Fi network, then open the address shown below on your phone."));
        Button start=action(wifi==null?"Start Wi-Fi Server":"Stop Wi-Fi Server",()->{if(wifi==null)startWifi();else stopWifi();});
        content.getChildren().add(start);
        Label address=new Label(wifi==null?"Server stopped":wifi.url);address.setStyle("-fx-text-fill:"+GOLD+";-fx-font-size:18px;");
        content.getChildren().add(address);
        content.getChildren().add(new Label("The Wi-Fi page supports uploading files from your phone. Incoming files are saved to VAULTX/incoming."));
        content.getChildren().addAll(
            action("Open incoming folder",()->openPath(incoming)),
            action("Import incoming files into vault",()->{
                try { List<File> files; try(var stream=Files.list(incoming)){files=stream.filter(Files::isRegularFile).map(Path::toFile).toList();}
                    if(!files.isEmpty())importFileList(files);else status.setText("NO INCOMING FILES");
                } catch(Exception ex){error(ex);}
            })
        );
    }
    private void startWifi() {
        try{wifi=new WiFiServer();wifi.start();status.setText("WI-FI TRANSFER ACTIVE");navigate("Phone Transfer");}
        catch(Exception e){wifi=null;error(e);}
    }
    private void stopWifi(){if(wifi!=null)wifi.stop();wifi=null;navigate("Phone Transfer");status.setText("WI-FI SERVER STOPPED");}
    private void showHistory() {
        content.getChildren().clear();heading("Transfer history","A record of files received or sent.");
        TableView<String[]> t=new TableView<>();t.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        for(int i=0;i<4;i++){final int x=i;TableColumn<String[],String> c=new TableColumn<>(List.of("FILE","DIRECTION","SIZE","TIME").get(i));c.setCellValueFactory(v->new javafx.beans.property.SimpleStringProperty(v.getValue()[x]));t.getColumns().add(c);}
        try(Statement s=db.createStatement();ResultSet rs=s.executeQuery("SELECT name,direction,size,time FROM transfers ORDER BY id DESC")){var l=FXCollections.<String[]>observableArrayList();while(rs.next())l.add(new String[]{rs.getString(1),rs.getString(2),human(rs.getLong(3)),rs.getString(4)});t.setItems(l);}catch(Exception e){error(e);}content.getChildren().add(t);
    }
    private void backupVault() {
        DirectoryChooser chooser=new DirectoryChooser();chooser.setTitle("Choose backup destination");
        File dest=chooser.showDialog(shell.getScene().getWindow());if(dest==null)return;
        Path out=dest.toPath().resolve("VAULTX_Backup_"+LocalDate.now()+".zip");
        try( java.util.zip.ZipOutputStream zip=new java.util.zip.ZipOutputStream(Files.newOutputStream(out)) ) {
            try(var paths=Files.walk(root)) {
                for(Path p:paths.filter(Files::isRegularFile).filter(x->!x.equals(out)).toList()) {
                    String entry=root.relativize(p).toString().replace("\\","/");
                    zip.putNextEntry(new java.util.zip.ZipEntry(entry));
                    Files.copy(p,zip);zip.closeEntry();
                }
            }
            status.setText("BACKUP CREATED: "+out.getFileName());
            new Alert(Alert.AlertType.INFORMATION,"Backup created successfully:\\n"+out,ButtonType.OK).showAndWait();
        }catch(Exception e){error(e);}
    }
    private void showTrash(){content.getChildren().clear();heading("Trash","Deleted items remain here until you restore or permanently remove them.");showFileTable(false,false,true);}
    private void showSettings(){content.getChildren().clear();heading("Settings","Local storage and application information.");
        content.getChildren().addAll(panel("Storage location",root.toString()),panel("Database","SQLite • Local only"),panel("Application","VAULTX 1.0 • Java 21"));
        content.getChildren().addAll(
            action("Open VAULTX data folder",()->openPath(root)),
            action("Create full backup ZIP",this::backupVault),
            action("Open stored files",()->openPath(stored)),
            action("Open incoming files",()->openPath(incoming))
        );
        content.getChildren().add(new Label("Security: this build does not yet encrypt stored files or provide an app password. Use Windows account security for device protection."));
    }
    private void showTrashDummy(){}
    private void toggleFavorite(FileRec f){if(f==null)return;update("UPDATE files SET favorite=1-favorite WHERE id=?",f.id);navigate(section);}
    private void trashFile(FileRec f){if(f==null)return;update("UPDATE files SET deleted=1 WHERE id=?",f.id);navigate(section);}
    private void restoreFile(FileRec f){if(f==null)return;update("UPDATE files SET deleted=0 WHERE id=?",f.id);navigate("Trash");}
    private void renameFile(FileRec f){if(f==null)return;TextInputDialog d=new TextInputDialog(f.name.get());d.setHeaderText("Rename file");d.showAndWait().ifPresent(v->{updateText("UPDATE files SET name=? WHERE id=?",v,f.id);navigate(section);});}
    private void exportFile(FileRec f){if(f==null)return;DirectoryChooser dc=new DirectoryChooser();dc.setTitle("Choose export folder");File dir=dc.showDialog(shell.getScene().getWindow());if(dir!=null)try{Files.copy(stored.resolve(f.stored),dir.toPath().resolve(f.name.get()),StandardCopyOption.REPLACE_EXISTING);}catch(Exception e){error(e);}}
    private void openFile(FileRec f){if(f!=null)openPath(stored.resolve(f.stored));}
    private void openPath(Path p){try{if(Desktop.isDesktopSupported())Desktop.getDesktop().open(p.toFile());}catch(Exception e){error(e);}}
    private void browse(String u){try{Desktop.getDesktop().browse(URI.create(u));}catch(Exception e){error(e);}}
    private void update(String sql,int id){try(PreparedStatement p=db.prepareStatement(sql)){p.setInt(1,id);p.executeUpdate();}catch(Exception e){error(e);}}
    private void updateText(String sql,String v,int id){try(PreparedStatement p=db.prepareStatement(sql)){p.setString(1,v);p.setInt(2,id);p.executeUpdate();}catch(Exception e){error(e);}}
    private int count(String table,String where)throws SQLException{try(Statement s=db.createStatement();ResultSet r=s.executeQuery("SELECT COUNT(*) FROM "+table+" WHERE "+where)){return r.next()?r.getInt(1):0;}}
    private long scalar(String q)throws SQLException{try(Statement s=db.createStatement();ResultSet r=s.executeQuery(q)){return r.next()?r.getLong(1):0;}}
    private void error(Throwable e){new Alert(Alert.AlertType.ERROR,"Operation failed: "+(e==null?"Unknown error":e.getMessage()),ButtonType.OK).show();if(e!=null)e.printStackTrace();}
    private static String now(){return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));}
    private static String extension(Path p){String n=p.getFileName().toString();int i=n.lastIndexOf('.');return i<0?"File":n.substring(i+1).toUpperCase(Locale.ROOT);}
    private static String safe(String s){return s.replaceAll("[^a-zA-Z0-9._ -]","_");}
    private static String human(long n){if(n<1024)return n+" B";if(n<1048576)return String.format("%.1f KB",n/1024.0);if(n<1073741824)return String.format("%.1f MB",n/1048576.0);return String.format("%.2f GB",n/1073741824.0);}
    @Override public void stop(){if(wifi!=null)wifi.stop();try{if(db!=null)db.close();}catch(Exception ignored){}}
    static class FileRec {
        int id; String stored; javafx.beans.property.SimpleStringProperty name,type,size,folder,added;
        FileRec(int id,String n,String s,String t,String z,String f,String a){this.id=id;stored=s;name=new javafx.beans.property.SimpleStringProperty(n);type=new javafx.beans.property.SimpleStringProperty(t);size=new javafx.beans.property.SimpleStringProperty(z);folder=new javafx.beans.property.SimpleStringProperty(f);added=new javafx.beans.property.SimpleStringProperty(a);}
    }
    static class LinkRec {
        int id; javafx.beans.property.SimpleStringProperty title,url,desc;
        LinkRec(int i,String t,String u,String d){id=i;title=new javafx.beans.property.SimpleStringProperty(t);url=new javafx.beans.property.SimpleStringProperty(u);desc=new javafx.beans.property.SimpleStringProperty(d==null?"":d);}
    }
    class WiFiServer {
        HttpServer server; String url; String token=UUID.randomUUID().toString().replace("-","");
        void start() throws Exception {
            int port=8765; server=HttpServer.create(new InetSocketAddress("0.0.0.0",port),0);
            server.createContext("/",x->{byte[] b=page().getBytes(java.nio.charset.StandardCharsets.UTF_8);x.getResponseHeaders().set("Content-Type","text/html; charset=utf-8");x.sendResponseHeaders(200,b.length);try(var o=x.getResponseBody()){o.write(b);}});
            server.createContext("/upload",x->{
                if(!"POST".equals(x.getRequestMethod())){x.sendResponseHeaders(405,-1);return;}
                String q=x.getRequestURI().getRawQuery();if(q==null||!q.contains("token="+token)){x.sendResponseHeaders(403,-1);return;}
                String raw=x.getRequestHeaders().getFirst("X-File-Name");String name=raw==null?"phone-upload.bin":URLDecoder.decode(raw,java.nio.charset.StandardCharsets.UTF_8);
                name=safe(Path.of(name).getFileName().toString());Path dest=incoming.resolve(System.currentTimeMillis()+"_"+name);
                long size=0;try(InputStream in=x.getRequestBody();OutputStream out=Files.newOutputStream(dest)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);size+=n;}}
                try(PreparedStatement p=db.prepareStatement("INSERT INTO transfers(name,direction,size,result,time) VALUES(?,?,?,?,?)")){p.setString(1,name);p.setString(2,"PHONE → PC");p.setLong(3,size);p.setString(4,"SUCCESS");p.setString(5,now());p.executeUpdate();}
                byte[] ok="Upload complete. You can close this page.".getBytes();x.sendResponseHeaders(200,ok.length);try(var o=x.getResponseBody()){o.write(ok);}
            });
            server.setExecutor(Executors.newCachedThreadPool());server.start();String ip=InetAddress.getLocalHost().getHostAddress();url="http://"+ip+":"+port+"/?token="+token;
        }
        String page(){return """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>VAULTX Transfer</title>
<style>body{background:#0b0d12;color:#eee;font:16px Arial;margin:0;padding:28px}main{max-width:560px;margin:30px auto;background:#171d28;padding:28px;border:1px solid #34303a;border-radius:18px}h1{color:#d8b46a}input,button{padding:14px;border-radius:10px;border:0;margin:8px 0;width:100%;box-sizing:border-box}button{background:#d8b46a;color:#111;font-weight:bold}small{color:#aab}</style></head>
<body><main><h1>VAULTX</h1><p>Secure local file transfer to your computer.</p><form id="f"><input id="files" type="file" multiple required><button>Send files to PC</button></form><p id="s"></p><small>Only use this page on a trusted Wi-Fi network. Session protected.</small></main>
<script>const token=new URLSearchParams(location.search).get('token');document.getElementById('f').onsubmit=async e=>{e.preventDefault();let fs=[...document.getElementById('files').files];for(let f of fs){document.getElementById('s').textContent='Uploading '+f.name;let r=await fetch('/upload?token='+encodeURIComponent(token),{method:'POST',headers:{'X-File-Name':encodeURIComponent(f.name)},body:f});if(!r.ok)throw new Error('Upload failed');}document.getElementById('s').textContent='All uploads complete.';};</script></body></html>""";}
        void stop(){server.stop(0);}
    }
}