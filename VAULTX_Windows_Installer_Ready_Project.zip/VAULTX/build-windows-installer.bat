@echo off
setlocal
title VAULTX Windows Installer Builder
echo ==========================================
echo        VAULTX - Windows Installer
echo ==========================================
echo.
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: JDK not found. Install a Windows JDK 21 or newer.
  pause
  exit /b 1
)
where mvn >nul 2>nul
if errorlevel 1 (
  echo ERROR: Maven is required only on the BUILD computer.
  echo End users of the generated EXE will not need Maven.
  pause
  exit /b 1
)
echo Building application...
call mvn --batch-mode clean package
if errorlevel 1 goto failed
echo Collecting runtime dependencies...
call mvn --batch-mode dependency:copy-dependencies -DincludeScope=runtime -DoutputDirectory=target/package-input
if errorlevel 1 goto failed
if not exist target\package-input mkdir target\package-input
copy /Y target\vaultx-1.0.0.jar target\package-input\
if errorlevel 1 goto failed
if not exist installer mkdir installer
echo Creating self-contained Windows installer...
jpackage --type exe --name VAULTX --app-version 2.0.0 --input target\package-input --main-jar vaultx-1.0.0.jar --main-class com.vaultex.App --dest installer --win-menu --win-shortcut --win-dir-chooser --vendor VAULTX --description "Personal Digital Storage and File Transfer Manager"
if errorlevel 1 goto failed
echo.
echo SUCCESS: Check the installer folder.
echo.
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. Read the error messages above.
pause
exit /b 1
