# VAULTX

A Java 21 + JavaFX desktop vault for Windows. It stores imported files in a private application data folder, records metadata in SQLite, manages links, and provides a local Wi-Fi transfer page.

## Requirements
- Windows 10/11
- JDK 21 (with `JAVA_HOME` configured)
- Maven 3.9+

## Run
Open a terminal in this folder:
```powershell
mvn clean javafx:run
```
Build a runnable shaded JAR:
```powershell
mvn clean package
```
JavaFX native runtime packaging may vary by machine; for a distributable Windows EXE, use `jpackage` with a Windows JDK and package the JavaFX runtime/modules for the target architecture.

## Storage
Data is kept under `%LOCALAPPDATA%\\VAULTX`:
- `vaultx.db` — SQLite metadata
- `files/` — imported files
- `incoming/` — files received over local Wi-Fi

Imported files are copied, not moved. The original remains unchanged.

## Phone transfer (Wi-Fi)
1. Connect the phone and PC to the same Wi-Fi network.
2. Open **Phone Transfer** and click **Start Wi-Fi Server**.
3. Open the displayed address on the phone browser and upload files.
4. The PC stores received files in `incoming/` and adds them to the vault.

The transfer server binds to all network interfaces. Use it only on a trusted private network. The upload page includes a one-time session token. Stop the server when finished.

## Bluetooth
The app provides a real hand-off to Windows' built-in Bluetooth File Transfer wizard (`fsquirt.exe`). Windows handles discovery, pairing, and the OBEX transfer. This is deliberately not represented as an in-app Bluetooth stack: Windows controls device permissions and pairing. Use **Open Bluetooth Transfer** in Phone Transfer.

## Expanded features in this build
- Drag-and-drop import from Windows Explorer.
- Keyboard shortcuts: Ctrl+O import, Ctrl+L save link, F5 refresh.
- Persistent named folders and importing directly into a selected folder.
- Move files between folders.
- SHA-256 duplicate detection during import.
- File detail dialog with original path and SHA-256 fingerprint.
- Permanent delete from Trash with confirmation.
- Link search, editing, favorites, copy and open actions.
- Unified Favorites page for both pinned files and links.
- Full ZIP backup of the local VAULTX data folder.
- Import received phone files from the Incoming folder into the managed vault.

## Current implementation scope
Implemented: persistent file import/copy, folders, file search, favorites, open/export/trash, link CRUD/open/copy, dashboard statistics, recent items, local Wi-Fi upload server, transfer history, Windows Bluetooth wizard hand-off, dark premium UI.
Security note: no cloud upload. The local Wi-Fi upload server is intended for trusted networks only. App password lock and at-rest encryption are not yet implemented; do not store highly sensitive secrets in this first release.


## Windows installer packaging
This repository now includes:
- `build-windows-installer.bat` to build a Windows EXE on a Windows build machine with a JDK and Maven.
- `.github/workflows/windows-installer.yml` to build the installer on GitHub Actions.

The generated EXE bundles a Java runtime using `jpackage`, so end-user PCs do not need Java or Maven installed. The build computer still needs a JDK, Maven, and internet access to download dependencies.

### GitHub Actions build
1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build VAULTX Windows installer**.
4. Press **Run workflow**.
5. When it finishes, open the workflow run and download the `VAULTX-Windows-Installer` artifact.

Important: this packaging setup has been prepared but not executed in this environment. A successful Windows build and installation test are still required before treating the EXE as release-ready.
