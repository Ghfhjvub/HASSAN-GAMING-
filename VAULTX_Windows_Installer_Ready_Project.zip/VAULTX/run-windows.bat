@echo off
title VAULTX
where mvn >nul 2>nul
if errorlevel 1 (
  echo Maven is not installed or not on PATH.
  echo Install JDK 21 and Maven 3.9+, then run this file again.
  pause
  exit /b 1
)
mvn clean javafx:run
pause
